Rise of Sovereigns - Build-ready project (v1.1)
This package contains runtime JSON configs, placeholder Android manifest,
GitHub Actions workflow for Flutter builds, and templates needed to build an APK
for the Rise of Sovereigns farm-sim game.
Files included:
- buildings.json
- npc.json
- research_tree.json
- economy.json
- bundle_config.json
- ads_config.json
- AndroidManifest.xml (placeholder)
- .github/workflows/build.yml (Flutter CI)
Notes:
- Replace AdMob APP ID meta-data with your real ID before production.
- Generate your own keystore.jks and add signing configs in android/app/build.gradle.
- This package assumes a Flutter-based project skeleton; adapt build.yml if you use Unity or native Android.
